#==========DANENDRA==========#

bilangan = 15

if bilangan % 2 == 0:
    print(bilangan, "adalah bilangan genap")
else : 
    print(bilangan, "adalah bilangan ganjil")