#==========DANENDRA==========#

user = "admin"
pw = "python"

username = input("masukan username anda : ")
password = input("masukan password anda : ")

if (password == pw) and (username == user):
    print("Login berhasil")
else :
    print("username atau password anda salah !!!")