#==========DANENDRA==========#

nilai = 55

if nilai <= 30:
    print("Sangat Buruk")
elif nilai <= 50:
    print("buruk")
elif nilai <= 70:
    print("cukup")
elif nilai <= 90:
    print("baik")
elif nilai <= 100:
    print("Sangat Baik")