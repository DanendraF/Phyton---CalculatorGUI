#==========DANENDRA==========#

x = 23
y = 30

if x == y:
    print(x, "mempunyai nilai sama dengan ", y)
else:
    if x > y:
        print(x, "lebih besar dari ", y)
    else :
        print(x, "lebih kecil dari ", y)