#==========DANENDRA==========#

bilangan = 5

if bilangan > 0:
    print(bilangan, " adalah bilangan positif")