#==========DANENDRA==========#

a1 = int(input("Masukkan jumlah a1: "))
a2 = int(input("Masukkan jumlah a2: "))
a3 = int(input("Masukkan jumlah a3: "))

if a1 >= a2:
    print("a1 lebih dari sama dengan a1 maka kita")
    
    if a1 >= a3:
        print("Masak rawon")
    else:
        print("Masak gulai")
else:
    print("a2 lebih dari sama dengan a3 maka kita")
    
    if a2 >= a3:
        print("Masak pecel")
    else:
        print("Masak gulai")
